-- SportsOS v0.3.7 Penalty Engine
-- Run once against the SportsOS MySQL database before starting the upgraded API.

ALTER TABLE game_projections
  ADD COLUMN penalties JSON NULL AFTER goals;
