"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { CirclePause, CirclePlay, Flag, Goal as GoalIcon, RotateCcw, ShieldAlert, Square, X } from "lucide-react";
import { toast } from "sonner";

import type { Game } from "@/features/games/models/game";
import { mapGame } from "@/features/games/mappers/game.mapper";
import type { GameDto } from "@/features/games/dto/game.dto";
import type { Player } from "@/features/players/models/player";
import { clientApiFetch } from "@/shared/api/client";

interface Props {
  initialGame: Game;
  homeTeamName: string;
  awayTeamName: string;
  homePlayers: Player[];
  awayPlayers: Player[];
}

interface GameResponse { game: GameDto; duplicate?: boolean }
type Side = "home" | "away";

function commandId(): string {
  return globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random()}`;
}

function formatClock(milliseconds: number): string {
  const safe = Math.max(0, milliseconds);
  const minutes = Math.floor(safe / 60_000);
  const seconds = Math.floor((safe % 60_000) / 1000);
  const tenths = Math.floor((safe % 1000) / 100);
  return safe < 60_000
    ? `${minutes}:${seconds.toString().padStart(2, "0")}.${tenths}`
    : `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

function playerLabel(player: Player): string {
  const name = [player.firstName, player.lastName].filter(Boolean).join(" ") || "Unnamed player";
  return player.number ? `#${player.number} ${name}` : name;
}

export function ScorekeeperConsole({ initialGame, homeTeamName, awayTeamName, homePlayers, awayPlayers }: Props) {
  const [game, setGame] = useState(initialGame);
  const [now, setNow] = useState(0);
  const [busy, setBusy] = useState(false);
  const [connected, setConnected] = useState(true);
  const [goalSide, setGoalSide] = useState<Side | null>(null);
  const [scorerId, setScorerId] = useState("");
  const [assist1Id, setAssist1Id] = useState("");
  const [assist2Id, setAssist2Id] = useState("");
  const [penaltySide, setPenaltySide] = useState<Side | null>(null);
  const [penaltyPlayerId, setPenaltyPlayerId] = useState("");
  const [penaltyInfraction, setPenaltyInfraction] = useState("Tripping");
  const [penaltyDuration, setPenaltyDuration] = useState("120000");

  const allPlayers = useMemo(() => [...homePlayers, ...awayPlayers], [homePlayers, awayPlayers]);
  const playerById = useMemo(() => new Map(allPlayers.map((player) => [player.id, player])), [allPlayers]);
  const selectedRoster = goalSide === "home" ? homePlayers : awayPlayers;
  const selectedPenaltyRoster = penaltySide === "home" ? homePlayers : awayPlayers;

  const displayedClock = useMemo(() => {
    if (!game.clock.running) return game.clock.remainingMilliseconds;
    const effectiveNow = now || new Date(game.updatedAt).getTime();
    const elapsed = Math.max(0, effectiveNow - new Date(game.updatedAt).getTime());
    return Math.max(0, game.clock.remainingMilliseconds - elapsed);
  }, [game, now]);

  const refresh = useCallback(async () => {
    try {
      const response = await clientApiFetch<GameResponse>(`/games/${game.id}`);
      setGame(mapGame(response.data.game));
      setConnected(true);
    } catch {
      setConnected(false);
    }
  }, [game.id]);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 100);
    const sync = window.setInterval(refresh, 2000);
    return () => { window.clearInterval(timer); window.clearInterval(sync); };
  }, [refresh]);

  async function execute(path: string, body?: unknown): Promise<boolean> {
    setBusy(true);
    try {
      const response = await clientApiFetch<GameResponse>(path, {
        method: "POST",
        headers: {
          "X-Command-Id": commandId(),
          "If-Match": String(game.lastEventSequence),
        },
        body: JSON.stringify(body ?? {}),
      });
      setGame(mapGame(response.data.game));
      setConnected(true);
      return true;
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Command failed.");
      await refresh();
      return false;
    } finally {
      setBusy(false);
    }
  }

  function openGoal(side: Side) {
    setGoalSide(side);
    setScorerId("");
    setAssist1Id("");
    setAssist2Id("");
  }

  async function saveGoal() {
    if (!goalSide) return;
    const assistIds = [assist1Id, assist2Id].filter(Boolean);
    const saved = await execute(`/games/${game.id}/goals`, {
      side: goalSide,
      scorer_id: scorerId || null,
      assist_ids: assistIds,
    });
    if (saved) setGoalSide(null);
  }

  function openPenalty(side: Side) {
    setPenaltySide(side);
    setPenaltyPlayerId("");
    setPenaltyInfraction("Tripping");
    setPenaltyDuration("120000");
  }

  async function savePenalty() {
    if (!penaltySide) return;
    const saved = await execute(`/games/${game.id}/penalties`, {
      side: penaltySide,
      player_id: penaltyPlayerId || null,
      infraction: penaltyInfraction,
      duration_milliseconds: Number(penaltyDuration),
    });
    if (saved) setPenaltySide(null);
  }

  const isFinal = game.status === "final";
  const canScore = game.status === "live" || game.status === "paused";

  return (
    <div className="mx-auto max-w-6xl space-y-4">
      <div className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900 px-4 py-3">
        <div><div className="text-sm font-semibold">Scorekeeper Console</div><div className="text-xs text-slate-500">Game {game.id}</div></div>
        <div className={connected ? "rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-semibold text-emerald-400" : "rounded-full bg-red-500/15 px-3 py-1 text-xs font-semibold text-red-400"}>{connected ? "Connected" : "Reconnecting"}</div>
      </div>

      <section className="rounded-2xl border border-slate-800 bg-slate-950 p-4 sm:p-6">
        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
          <div className="text-center"><div className="truncate text-sm text-slate-400 sm:text-xl">{awayTeamName}</div><div className="mt-2 text-6xl font-black sm:text-8xl">{game.awayScore}</div></div>
          <div className="text-center"><div className="font-mono text-5xl font-black tracking-tight sm:text-7xl">{formatClock(displayedClock)}</div><div className="mt-2 text-lg font-semibold text-slate-400">Period {game.clock.period}</div><div className="mt-1 text-xs uppercase tracking-widest text-slate-600">{game.status}</div></div>
          <div className="text-center"><div className="truncate text-sm text-slate-400 sm:text-xl">{homeTeamName}</div><div className="mt-2 text-6xl font-black sm:text-8xl">{game.homeScore}</div></div>
        </div>
      </section>

      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {game.status === "scheduled" ? (
          <button disabled={busy} onClick={() => execute(`/games/${game.id}/start`)} className="min-h-24 rounded-xl bg-emerald-600 p-4 text-lg font-bold hover:bg-emerald-500 disabled:opacity-50"><Flag className="mx-auto mb-2 h-7 w-7" />Start Game</button>
        ) : game.clock.running ? (
          <button disabled={busy} onClick={() => execute(`/games/${game.id}/clock/stop`, { remaining_milliseconds: Math.round(displayedClock) })} className="min-h-24 rounded-xl bg-amber-600 p-4 text-lg font-bold hover:bg-amber-500 disabled:opacity-50"><CirclePause className="mx-auto mb-2 h-7 w-7" />Stop Clock</button>
        ) : (
          <button disabled={busy || isFinal} onClick={() => execute(`/games/${game.id}/clock/start`)} className="min-h-24 rounded-xl bg-emerald-600 p-4 text-lg font-bold hover:bg-emerald-500 disabled:opacity-50"><CirclePlay className="mx-auto mb-2 h-7 w-7" />Start Clock</button>
        )}
        <button disabled={busy || !canScore} onClick={() => openGoal("away")} className="min-h-24 rounded-xl bg-sky-700 p-4 text-lg font-bold hover:bg-sky-600 disabled:opacity-50"><GoalIcon className="mx-auto mb-2 h-7 w-7" />Away Goal</button>
        <button disabled={busy || !canScore} onClick={() => openGoal("home")} className="min-h-24 rounded-xl bg-sky-700 p-4 text-lg font-bold hover:bg-sky-600 disabled:opacity-50"><GoalIcon className="mx-auto mb-2 h-7 w-7" />Home Goal</button>
        <button disabled={busy || game.clock.running || isFinal} onClick={() => execute(`/games/${game.id}/period/advance`, {})} className="min-h-24 rounded-xl bg-violet-700 p-4 text-lg font-bold hover:bg-violet-600 disabled:opacity-50"><RotateCcw className="mx-auto mb-2 h-7 w-7" />Next Period</button>
      </section>

      <section className="grid gap-3 sm:grid-cols-2">
        <button disabled={busy || !canScore} onClick={() => openPenalty("away")} className="min-h-20 rounded-xl bg-orange-700 p-4 text-lg font-bold hover:bg-orange-600 disabled:opacity-50"><ShieldAlert className="mx-auto mb-2 h-6 w-6" />Away Penalty</button>
        <button disabled={busy || !canScore} onClick={() => openPenalty("home")} className="min-h-20 rounded-xl bg-orange-700 p-4 text-lg font-bold hover:bg-orange-600 disabled:opacity-50"><ShieldAlert className="mx-auto mb-2 h-6 w-6" />Home Penalty</button>
      </section>

      <section className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <h3 className="font-semibold">Recent Penalties</h3>
          <div className="mt-3 space-y-2">
            {game.penalties.filter((penalty) => !penalty.voided).slice().reverse().map((penalty) => {
              const player = penalty.playerId ? playerById.get(penalty.playerId) : null;
              return <div key={penalty.penaltyId} className="flex items-start justify-between gap-3 rounded-lg bg-slate-950 px-3 py-2 text-sm">
                <div><div className="font-medium">{penalty.side === "home" ? homeTeamName : awayTeamName} — {player ? playerLabel(player) : "Team penalty"}</div><div className="text-xs text-slate-500">{penalty.infraction} • {formatClock(penalty.durationMilliseconds)} • P{penalty.period} {formatClock(penalty.clockMilliseconds)}</div></div>
                <button disabled={busy || isFinal} onClick={() => execute(`/games/${game.id}/penalties/${penalty.penaltyId}/void`, { reason: "Scorekeeper correction" })} className="rounded-md border border-slate-700 px-2 py-1 text-xs text-slate-300 hover:bg-slate-800 disabled:opacity-50">Undo</button>
              </div>;
            })}
            {!game.penalties.some((penalty) => !penalty.voided) && <p className="text-sm text-slate-500">No penalties recorded.</p>}
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <h3 className="font-semibold">Penalty Summary</h3>
          <div className="mt-3 grid grid-cols-2 gap-3 text-center">
            <div className="rounded-lg bg-slate-950 p-4"><div className="text-xs text-slate-500">{awayTeamName}</div><div className="mt-1 text-3xl font-black">{game.penalties.filter((p) => !p.voided && p.side === "away").length}</div></div>
            <div className="rounded-lg bg-slate-950 p-4"><div className="text-xs text-slate-500">{homeTeamName}</div><div className="mt-1 text-3xl font-black">{game.penalties.filter((p) => !p.voided && p.side === "home").length}</div></div>
          </div>
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-[1fr_280px]">
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
          <h3 className="font-semibold">Recent Goals</h3>
          <div className="mt-3 space-y-2">
            {game.goals.filter((goal) => !goal.voided).slice().reverse().map((goal) => {
              const scorer = goal.scorerId ? playerById.get(goal.scorerId) : null;
              const assists = goal.assistIds.map((id) => playerById.get(id)).filter((player): player is Player => Boolean(player));
              return <div key={goal.goalId} className="flex items-start justify-between gap-3 rounded-lg bg-slate-950 px-3 py-2 text-sm">
                <div><div className="font-medium">{goal.side === "home" ? homeTeamName : awayTeamName} — {scorer ? playerLabel(scorer) : "Unassisted / player not selected"}</div><div className="text-xs text-slate-500">P{goal.period} {formatClock(goal.clockMilliseconds)}{assists.length ? ` • Assists: ${assists.map(playerLabel).join(", ")}` : ""}</div></div>
                <button disabled={busy || isFinal} onClick={() => execute(`/games/${game.id}/goals/${goal.goalId}/void`, { reason: "Scorekeeper correction" })} className="rounded-md border border-slate-700 px-2 py-1 text-xs text-slate-300 hover:bg-slate-800 disabled:opacity-50">Undo</button>
              </div>;
            })}
            {!game.goals.some((goal) => !goal.voided) && <p className="text-sm text-slate-500">No goals recorded.</p>}
          </div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900 p-4"><h3 className="font-semibold">Game Controls</h3><button disabled={busy || game.clock.running || isFinal || game.status === "scheduled"} onClick={() => execute(`/games/${game.id}/end`)} className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg bg-red-700 px-4 py-3 font-semibold hover:bg-red-600 disabled:opacity-50"><Square className="h-4 w-4" />End Game</button><p className="mt-3 text-xs text-slate-500">The clock must be stopped before advancing the period or ending the game.</p></div>
      </section>

      {penaltySide && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4" role="dialog" aria-modal="true">
        <div className="w-full max-w-xl rounded-2xl border border-slate-700 bg-slate-900 p-5 shadow-2xl">
          <div className="flex items-center justify-between"><div><h2 className="text-xl font-bold">Record {penaltySide === "home" ? homeTeamName : awayTeamName} Penalty</h2><p className="text-sm text-slate-400">P{game.clock.period} • {formatClock(displayedClock)}</p></div><button onClick={() => setPenaltySide(null)} className="rounded-lg p-2 hover:bg-slate-800" aria-label="Close"><X /></button></div>
          <div className="mt-5 grid gap-4">
            <label className="grid gap-1 text-sm font-medium">Player<select value={penaltyPlayerId} onChange={(event) => setPenaltyPlayerId(event.target.value)} className="min-h-12 rounded-lg border border-slate-700 bg-slate-950 px-3"><option value="">Team penalty / no player selected</option>{selectedPenaltyRoster.map((player) => <option key={player.id} value={player.id}>{playerLabel(player)}</option>)}</select></label>
            <label className="grid gap-1 text-sm font-medium">Infraction<select value={penaltyInfraction} onChange={(event) => setPenaltyInfraction(event.target.value)} className="min-h-12 rounded-lg border border-slate-700 bg-slate-950 px-3"><option>Tripping</option><option>Hooking</option><option>Slashing</option><option>Interference</option><option>Holding</option><option>Cross-checking</option><option>Roughing</option><option>High-sticking</option><option>Too many players</option><option>Unsportsmanlike conduct</option><option>Other</option></select></label>
            <label className="grid gap-1 text-sm font-medium">Duration<select value={penaltyDuration} onChange={(event) => setPenaltyDuration(event.target.value)} className="min-h-12 rounded-lg border border-slate-700 bg-slate-950 px-3"><option value="120000">2:00 Minor</option><option value="240000">4:00 Double Minor</option><option value="300000">5:00 Major</option><option value="600000">10:00 Misconduct</option></select></label>
          </div>
          <div className="mt-6 grid grid-cols-2 gap-3"><button disabled={busy} onClick={() => setPenaltySide(null)} className="min-h-12 rounded-lg border border-slate-700 font-semibold hover:bg-slate-800">Cancel</button><button disabled={busy || !penaltyInfraction.trim()} onClick={savePenalty} className="min-h-12 rounded-lg bg-orange-600 font-semibold hover:bg-orange-500 disabled:opacity-50">Save Penalty</button></div>
        </div>
      </div>}

      {goalSide && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4" role="dialog" aria-modal="true">
        <div className="w-full max-w-xl rounded-2xl border border-slate-700 bg-slate-900 p-5 shadow-2xl">
          <div className="flex items-center justify-between"><div><h2 className="text-xl font-bold">Record {goalSide === "home" ? homeTeamName : awayTeamName} Goal</h2><p className="text-sm text-slate-400">P{game.clock.period} • {formatClock(displayedClock)}</p></div><button onClick={() => setGoalSide(null)} className="rounded-lg p-2 hover:bg-slate-800" aria-label="Close"><X /></button></div>
          <div className="mt-5 grid gap-4">
            <label className="grid gap-1 text-sm font-medium">Scorer<select value={scorerId} onChange={(event) => { setScorerId(event.target.value); if (assist1Id === event.target.value) setAssist1Id(""); if (assist2Id === event.target.value) setAssist2Id(""); }} className="min-h-12 rounded-lg border border-slate-700 bg-slate-950 px-3"><option value="">No player selected</option>{selectedRoster.map((player) => <option key={player.id} value={player.id}>{playerLabel(player)}</option>)}</select></label>
            <label className="grid gap-1 text-sm font-medium">Assist 1<select disabled={!scorerId} value={assist1Id} onChange={(event) => { setAssist1Id(event.target.value); if (assist2Id === event.target.value) setAssist2Id(""); }} className="min-h-12 rounded-lg border border-slate-700 bg-slate-950 px-3 disabled:opacity-50"><option value="">None</option>{selectedRoster.filter((player) => player.id !== scorerId).map((player) => <option key={player.id} value={player.id}>{playerLabel(player)}</option>)}</select></label>
            <label className="grid gap-1 text-sm font-medium">Assist 2<select disabled={!scorerId} value={assist2Id} onChange={(event) => setAssist2Id(event.target.value)} className="min-h-12 rounded-lg border border-slate-700 bg-slate-950 px-3 disabled:opacity-50"><option value="">None</option>{selectedRoster.filter((player) => player.id !== scorerId && player.id !== assist1Id).map((player) => <option key={player.id} value={player.id}>{playerLabel(player)}</option>)}</select></label>
          </div>
          {selectedRoster.length === 0 && <p className="mt-4 rounded-lg border border-amber-700/50 bg-amber-500/10 p-3 text-sm text-amber-300">This team has no players yet. You can still record the goal without player attribution.</p>}
          <div className="mt-6 grid grid-cols-2 gap-3"><button disabled={busy} onClick={() => setGoalSide(null)} className="min-h-12 rounded-lg border border-slate-700 font-semibold hover:bg-slate-800">Cancel</button><button disabled={busy} onClick={saveGoal} className="min-h-12 rounded-lg bg-sky-600 font-semibold hover:bg-sky-500 disabled:opacity-50">Save Goal</button></div>
        </div>
      </div>}
    </div>
  );
}
