export const gameStatuses = ["scheduled", "live", "paused", "final"] as const;
export type GameStatus = (typeof gameStatuses)[number];

export interface Goal {
  goalId: string;
  side: "home" | "away";
  scorerId: string | null;
  assistIds: string[];
  period: number;
  clockMilliseconds: number;
  voided: boolean;
}

export interface Penalty {
  penaltyId: string;
  side: "home" | "away";
  playerId: string | null;
  infraction: string;
  durationMilliseconds: number;
  period: number;
  clockMilliseconds: number;
  voided: boolean;
}

export interface GameClock {
  period: number;
  remainingMilliseconds: number;
  running: boolean;
}

export interface Game {
  id: string;
  organizationId: string;
  homeTeamId: string;
  awayTeamId: string;
  scheduledAt: string;
  venue: string | null;
  status: GameStatus;
  homeScore: number;
  awayScore: number;
  clock: GameClock;
  goals: Goal[];
  penalties: Penalty[];
  lastEventSequence: number;
  updatedAt: string;
}

export interface CreateGameInput {
  organizationId: string;
  homeTeamId: string;
  awayTeamId: string;
  scheduledAt: string;
  venue?: string;
}
