import type { GameDto } from "../dto/game.dto";
import type { Game } from "../models/game";

export function mapGame(dto: GameDto): Game {
  return {
    id: dto.id,
    organizationId: dto.organization_id,
    homeTeamId: dto.home_team_id,
    awayTeamId: dto.away_team_id,
    scheduledAt: dto.scheduled_at,
    venue: dto.venue,
    status: dto.status,
    homeScore: dto.home_score,
    awayScore: dto.away_score,
    clock: {
      period: dto.period,
      remainingMilliseconds: dto.clock_milliseconds,
      running: dto.clock_running,
    },
    goals: dto.goals.map((goal) => ({
      goalId: goal.goalId,
      side: goal.side,
      scorerId: goal.scorerId,
      assistIds: goal.assistIds,
      period: goal.period,
      clockMilliseconds: goal.clockMilliseconds,
      voided: goal.voided,
    })),
    penalties: (dto.penalties ?? []).map((penalty) => ({
      penaltyId: penalty.penaltyId,
      side: penalty.side,
      playerId: penalty.playerId,
      infraction: penalty.infraction,
      durationMilliseconds: penalty.durationMilliseconds,
      period: penalty.period,
      clockMilliseconds: penalty.clockMilliseconds,
      voided: penalty.voided,
    })),
    lastEventSequence: dto.last_event_sequence,
    updatedAt: dto.updated_at,
  };
}
