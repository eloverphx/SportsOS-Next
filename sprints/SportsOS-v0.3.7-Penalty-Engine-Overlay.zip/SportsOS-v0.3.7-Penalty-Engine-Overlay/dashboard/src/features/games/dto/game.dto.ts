export interface GoalDto {
  goalId: string;
  side: "home" | "away";
  scorerId: string | null;
  assistIds: string[];
  period: number;
  clockMilliseconds: number;
  voided: boolean;
}

export interface PenaltyDto {
  penaltyId: string;
  side: "home" | "away";
  playerId: string | null;
  infraction: string;
  durationMilliseconds: number;
  period: number;
  clockMilliseconds: number;
  voided: boolean;
}

export interface GameDto {
  id: string;
  organization_id: string;
  home_team_id: string;
  away_team_id: string;
  scheduled_at: string;
  venue: string | null;
  status: "scheduled" | "live" | "paused" | "final";
  home_score: number;
  away_score: number;
  period: number;
  clock_milliseconds: number;
  clock_running: boolean;
  goals: GoalDto[];
  penalties: PenaltyDto[];
  last_event_sequence: number;
  updated_at: string;
}
