# SportsOS v0.3.7 — Penalty Engine Phase 1

Adds event-sourced hockey penalties to Game Center.

## Included
- Record home or away penalties from the scorekeeper console
- Select a rostered player or record a team penalty
- Common hockey infraction presets
- 2-minute, 4-minute, 5-minute, and 10-minute durations
- Roster/team validation in the API
- Event-store persistence and projection rebuilding
- Realtime game event broadcasting through the existing event bus
- Undo/void penalty corrections
- Penalty list and team summary in the scorekeeper UI

## Required database upgrade
Run `dashboard/docs/database/002_game_penalties.sql` once before starting the upgraded API.

## Test checklist
1. Start a scheduled game.
2. Record a home penalty with a rostered player.
3. Record an away team penalty without a player.
4. Confirm both appear in Recent Penalties.
5. Undo one penalty.
6. Refresh the page and confirm the remaining penalty persists.
7. Attempt to assign a player from the wrong team and confirm the API rejects it.
