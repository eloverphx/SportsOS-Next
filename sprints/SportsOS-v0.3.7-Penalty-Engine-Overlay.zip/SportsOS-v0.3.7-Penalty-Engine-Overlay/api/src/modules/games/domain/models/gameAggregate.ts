import { DomainError } from "../../../../shared/domain/errors";
import type { Clock } from "../../../../shared/time/clock";
import type { NewDomainEvent, DomainEvent } from "../../../../shared/events/domainEvent";
import type { GameCommand } from "../commands/gameCommands";
import type { GameEvent, GameEventType } from "../events/gameEvents";

interface AggregateState {
  exists: boolean;
  status: "scheduled" | "live" | "paused" | "final";
  clockRunning: boolean;
  clockMilliseconds: number;
  period: number;
  homeTeamId: string;
  awayTeamId: string;
  goals: Map<string, { side: "home" | "away"; voided: boolean }>;
  penalties: Map<string, { side: "home" | "away"; voided: boolean }>;
}

export class GameAggregate {
  private state: AggregateState = {
    exists: false, status: "scheduled", clockRunning: false,
    clockMilliseconds: 20 * 60 * 1000, period: 1,
    homeTeamId: "", awayTeamId: "", goals: new Map(), penalties: new Map(),
  };
  private version = 0;

  constructor(private readonly gameId: string, private readonly clock: Clock) {}

  static rehydrate(gameId: string, events: DomainEvent[], clock: Clock): GameAggregate {
    const aggregate = new GameAggregate(gameId, clock);
    for (const event of events) aggregate.apply(event as GameEvent);
    return aggregate;
  }

  getVersion(): number { return this.version; }
  getTeamId(side: "home" | "away"): string {
    this.assertExistsAndNotFinal();
    return side === "home" ? this.state.homeTeamId : this.state.awayTeamId;
  }

  execute(command: GameCommand): NewDomainEvent[] {
    if (command.gameId !== this.gameId) throw new DomainError("Command game ID does not match aggregate.", "GAME_ID_MISMATCH");
    const metadata = {
      actorId: command.actorId,
      correlationId: command.correlationId,
      causationId: command.causationId ?? null,
      commandId: command.commandId,
    };
    const event = <T>(type: GameEventType, payload: T): NewDomainEvent<GameEventType, T> => ({
      aggregateId: this.gameId,
      aggregateType: "game",
      type,
      version: 1,
      payload,
      metadata,
    });

    switch (command.type) {
      case "CreateGame": {
        if (this.state.exists) throw new DomainError("Game already exists.", "GAME_ALREADY_EXISTS", 409);
        if (command.homeTeamId === command.awayTeamId) throw new DomainError("Home and away teams must be different.", "SAME_TEAM");
        const scheduledAt = new Date(command.scheduledAt);
        if (Number.isNaN(scheduledAt.getTime())) throw new DomainError("scheduledAt must be a valid date.", "INVALID_DATE");
        return [event("game.created", {
          organizationId: command.organizationId,
          homeTeamId: command.homeTeamId,
          awayTeamId: command.awayTeamId,
          scheduledAt: scheduledAt.toISOString(),
          venue: command.venue?.trim() || null,
          initialPeriodMilliseconds: command.initialPeriodMilliseconds ?? 20 * 60 * 1000,
        })];
      }
      case "StartGame":
        this.assertExistsAndNotFinal();
        if (this.state.status === "live") throw new DomainError("Game is already live.", "GAME_ALREADY_LIVE", 409);
        return [event("game.started", { startedAt: this.clock.now().toISOString() })];
      case "StartClock":
        this.assertLive();
        if (this.state.clockRunning) throw new DomainError("Clock is already running.", "CLOCK_ALREADY_RUNNING", 409);
        if (this.state.clockMilliseconds <= 0) throw new DomainError("Clock must have time remaining.", "CLOCK_EMPTY");
        return [event("game.clock_started", { startedAt: this.clock.now().toISOString(), remainingMilliseconds: this.state.clockMilliseconds })];
      case "StopClock":
        this.assertLive();
        if (!this.state.clockRunning) throw new DomainError("Clock is not running.", "CLOCK_NOT_RUNNING", 409);
        this.assertMilliseconds(command.remainingMilliseconds);
        return [event("game.clock_stopped", { stoppedAt: this.clock.now().toISOString(), remainingMilliseconds: command.remainingMilliseconds })];
      case "SetClock":
        this.assertExistsAndNotFinal();
        if (this.state.clockRunning) throw new DomainError("Stop the clock before setting it.", "CLOCK_RUNNING", 409);
        this.assertMilliseconds(command.remainingMilliseconds);
        return [event("game.clock_set", { remainingMilliseconds: command.remainingMilliseconds })];
      case "AdvancePeriod":
        this.assertExistsAndNotFinal();
        if (this.state.clockRunning) throw new DomainError("Stop the clock before advancing the period.", "CLOCK_RUNNING", 409);
        return [event("game.period_advanced", {
          period: this.state.period + 1,
          remainingMilliseconds: command.remainingMilliseconds ?? 20 * 60 * 1000,
        })];
      case "RecordGoal": {
        this.assertLive();
        if (this.state.goals.has(command.goalId)) throw new DomainError("Goal ID already exists.", "GOAL_ALREADY_EXISTS", 409);
        const assistIds = [...new Set(command.assistIds ?? [])];
        if (assistIds.length > 2) throw new DomainError("A goal can have at most two assists.", "TOO_MANY_ASSISTS");
        if (!command.scorerId && assistIds.length > 0) throw new DomainError("Assists require a scorer.", "ASSISTS_REQUIRE_SCORER");
        if (command.scorerId && assistIds.includes(command.scorerId)) throw new DomainError("The scorer cannot also be credited with an assist.", "SCORER_IS_ASSIST");
        return [event("game.goal_recorded", {
          goalId: command.goalId,
          side: command.side,
          scorerId: command.scorerId ?? null,
          assistIds,
          period: this.state.period,
          clockMilliseconds: this.state.clockMilliseconds,
        })];
      }
      case "VoidGoal": {
        this.assertExistsAndNotFinal();
        const goal = this.state.goals.get(command.goalId);
        if (!goal) throw new DomainError("Goal not found.", "GOAL_NOT_FOUND", 404);
        if (goal.voided) throw new DomainError("Goal is already voided.", "GOAL_ALREADY_VOIDED", 409);
        return [event("game.goal_voided", { goalId: command.goalId, reason: command.reason.trim() || "Correction" })];
      }
      case "RecordPenalty": {
        this.assertLive();
        if (this.state.penalties.has(command.penaltyId)) throw new DomainError("Penalty ID already exists.", "PENALTY_ALREADY_EXISTS", 409);
        this.assertPenaltyDuration(command.durationMilliseconds);
        const infraction = command.infraction.trim();
        if (!infraction) throw new DomainError("Penalty infraction is required.", "PENALTY_INFRACTION_REQUIRED");
        return [event("game.penalty_recorded", {
          penaltyId: command.penaltyId,
          side: command.side,
          playerId: command.playerId ?? null,
          infraction,
          durationMilliseconds: command.durationMilliseconds,
          period: this.state.period,
          clockMilliseconds: this.state.clockMilliseconds,
        })];
      }
      case "VoidPenalty": {
        this.assertExistsAndNotFinal();
        const penalty = this.state.penalties.get(command.penaltyId);
        if (!penalty) throw new DomainError("Penalty not found.", "PENALTY_NOT_FOUND", 404);
        if (penalty.voided) throw new DomainError("Penalty is already voided.", "PENALTY_ALREADY_VOIDED", 409);
        return [event("game.penalty_voided", { penaltyId: command.penaltyId, reason: command.reason.trim() || "Correction" })];
      }
      case "EndGame":
        this.assertExistsAndNotFinal();
        if (this.state.clockRunning) throw new DomainError("Stop the clock before ending the game.", "CLOCK_RUNNING", 409);
        return [event("game.ended", { endedAt: this.clock.now().toISOString() })];
    }
  }

  private assertExistsAndNotFinal() {
    if (!this.state.exists) throw new DomainError("Game not found.", "GAME_NOT_FOUND", 404);
    if (this.state.status === "final") throw new DomainError("Game is final and cannot be changed.", "GAME_FINAL", 409);
  }
  private assertLive() {
    this.assertExistsAndNotFinal();
    if (this.state.status !== "live" && this.state.status !== "paused") throw new DomainError("Game must be started first.", "GAME_NOT_STARTED", 409);
  }
  private assertMilliseconds(value: number) {
    if (!Number.isInteger(value) || value < 0 || value > 24 * 60 * 60 * 1000) throw new DomainError("Clock value is invalid.", "INVALID_CLOCK");
  }
  private assertPenaltyDuration(value: number) {
    if (!Number.isInteger(value) || value < 30_000 || value > 10 * 60 * 1000) {
      throw new DomainError("Penalty duration must be between 30 seconds and 10 minutes.", "INVALID_PENALTY_DURATION");
    }
  }

  private apply(event: GameEvent) {
    this.version = event.sequence;
    switch (event.type) {
      case "game.created":
        this.state.exists = true;
        this.state.homeTeamId = event.payload.homeTeamId;
        this.state.awayTeamId = event.payload.awayTeamId;
        this.state.clockMilliseconds = event.payload.initialPeriodMilliseconds;
        break;
      case "game.started": this.state.status = "live"; break;
      case "game.clock_started": this.state.clockRunning = true; this.state.status = "live"; break;
      case "game.clock_stopped": this.state.clockRunning = false; this.state.status = "paused"; this.state.clockMilliseconds = event.payload.remainingMilliseconds; break;
      case "game.clock_set": this.state.clockMilliseconds = event.payload.remainingMilliseconds; break;
      case "game.period_advanced": this.state.period = event.payload.period; this.state.clockMilliseconds = event.payload.remainingMilliseconds; break;
      case "game.goal_recorded": this.state.goals.set(event.payload.goalId, { side: event.payload.side, voided: false }); break;
      case "game.goal_voided": { const goal = this.state.goals.get(event.payload.goalId); if (goal) goal.voided = true; break; }
      case "game.penalty_recorded": this.state.penalties.set(event.payload.penaltyId, { side: event.payload.side, voided: false }); break;
      case "game.penalty_voided": { const penalty = this.state.penalties.get(event.payload.penaltyId); if (penalty) penalty.voided = true; break; }
      case "game.ended": this.state.status = "final"; this.state.clockRunning = false; break;
    }
  }
}
