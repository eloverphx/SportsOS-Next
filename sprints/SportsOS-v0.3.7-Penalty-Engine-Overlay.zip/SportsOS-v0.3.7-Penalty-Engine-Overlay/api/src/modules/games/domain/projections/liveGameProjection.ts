import type { GameStatus } from "../events/gameEvents";

export interface GoalProjection {
  goalId: string;
  side: "home" | "away";
  scorerId: string | null;
  assistIds: string[];
  period: number;
  clockMilliseconds: number;
  voided: boolean;
}

export interface PenaltyProjection {
  penaltyId: string;
  side: "home" | "away";
  playerId: string | null;
  infraction: string;
  durationMilliseconds: number;
  period: number;
  clockMilliseconds: number;
  voided: boolean;
}

export interface LiveGameProjection {
  gameId: string;
  organizationId: string;
  homeTeamId: string;
  awayTeamId: string;
  scheduledAt: string;
  venue: string | null;
  status: GameStatus;
  homeScore: number;
  awayScore: number;
  period: number;
  clockMilliseconds: number;
  clockRunning: boolean;
  goals: GoalProjection[];
  penalties: PenaltyProjection[];
  lastEventSequence: number;
  updatedAt: string;
}
