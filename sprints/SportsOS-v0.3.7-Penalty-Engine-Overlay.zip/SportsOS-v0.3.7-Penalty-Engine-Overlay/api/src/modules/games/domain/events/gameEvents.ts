import type { DomainEvent } from "../../../../shared/events/domainEvent";

export type GameStatus = "scheduled" | "live" | "paused" | "final";
export type TeamSide = "home" | "away";

export interface GameCreatedPayload {
  organizationId: string;
  homeTeamId: string;
  awayTeamId: string;
  scheduledAt: string;
  venue: string | null;
  initialPeriodMilliseconds: number;
}
export interface GameStartedPayload { startedAt: string }
export interface ClockStartedPayload { startedAt: string; remainingMilliseconds: number }
export interface ClockStoppedPayload { stoppedAt: string; remainingMilliseconds: number }
export interface ClockSetPayload { remainingMilliseconds: number }
export interface PeriodAdvancedPayload { period: number; remainingMilliseconds: number }
export interface GoalRecordedPayload {
  goalId: string;
  side: TeamSide;
  scorerId: string | null;
  assistIds: string[];
  period: number;
  clockMilliseconds: number;
}
export interface GoalVoidedPayload { goalId: string; reason: string }
export interface PenaltyRecordedPayload {
  penaltyId: string;
  side: TeamSide;
  playerId: string | null;
  infraction: string;
  durationMilliseconds: number;
  period: number;
  clockMilliseconds: number;
}
export interface PenaltyVoidedPayload { penaltyId: string; reason: string }
export interface GameEndedPayload { endedAt: string }

export type GameEventType =
  | "game.created"
  | "game.started"
  | "game.clock_started"
  | "game.clock_stopped"
  | "game.clock_set"
  | "game.period_advanced"
  | "game.goal_recorded"
  | "game.goal_voided"
  | "game.penalty_recorded"
  | "game.penalty_voided"
  | "game.ended";

export type GameEvent = DomainEvent<GameEventType, any>;
