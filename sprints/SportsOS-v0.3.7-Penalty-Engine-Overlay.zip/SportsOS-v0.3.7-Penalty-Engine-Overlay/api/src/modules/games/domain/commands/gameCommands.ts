import type { TeamSide } from "../events/gameEvents";

export interface CommandContext {
  commandId: string;
  actorId: string;
  correlationId: string;
  causationId?: string | null;
  expectedVersion?: number;
}

export interface CreateGameCommand extends CommandContext {
  type: "CreateGame";
  gameId: string;
  organizationId: string;
  homeTeamId: string;
  awayTeamId: string;
  scheduledAt: string;
  venue?: string | null;
  initialPeriodMilliseconds?: number;
}
export interface StartGameCommand extends CommandContext { type: "StartGame"; gameId: string }
export interface StartClockCommand extends CommandContext { type: "StartClock"; gameId: string }
export interface StopClockCommand extends CommandContext { type: "StopClock"; gameId: string; remainingMilliseconds: number }
export interface SetClockCommand extends CommandContext { type: "SetClock"; gameId: string; remainingMilliseconds: number }
export interface AdvancePeriodCommand extends CommandContext { type: "AdvancePeriod"; gameId: string; remainingMilliseconds?: number }
export interface RecordGoalCommand extends CommandContext {
  type: "RecordGoal";
  gameId: string;
  goalId: string;
  side: TeamSide;
  scorerId?: string | null;
  assistIds?: string[];
}
export interface VoidGoalCommand extends CommandContext { type: "VoidGoal"; gameId: string; goalId: string; reason: string }
export interface RecordPenaltyCommand extends CommandContext {
  type: "RecordPenalty";
  gameId: string;
  penaltyId: string;
  side: TeamSide;
  playerId?: string | null;
  infraction: string;
  durationMilliseconds: number;
}
export interface VoidPenaltyCommand extends CommandContext { type: "VoidPenalty"; gameId: string; penaltyId: string; reason: string }
export interface EndGameCommand extends CommandContext { type: "EndGame"; gameId: string }

export type GameCommand =
  | CreateGameCommand | StartGameCommand | StartClockCommand | StopClockCommand
  | SetClockCommand | AdvancePeriodCommand | RecordGoalCommand | VoidGoalCommand
  | RecordPenaltyCommand | VoidPenaltyCommand | EndGameCommand;
