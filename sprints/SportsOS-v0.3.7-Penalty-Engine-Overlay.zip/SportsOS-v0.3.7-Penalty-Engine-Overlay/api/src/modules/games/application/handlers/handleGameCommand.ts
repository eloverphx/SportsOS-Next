import { DomainError } from "../../../../shared/domain/errors";
import type { EventBus } from "../../../../shared/events/eventBus";
import type { EventStore } from "../../../../shared/persistence/eventStore";
import type { Clock } from "../../../../shared/time/clock";
import type { ProjectionManager } from "../../../../shared/projections/projectionManager";
import type { CommandHandler } from "../../../../shared/commands/command";
import type { GameCommand } from "../../domain/commands/gameCommands";
import type { LiveGameProjection } from "../../domain/projections/liveGameProjection";
import { GameAggregate } from "../../domain/models/gameAggregate";
import type { PlayerRosterReader } from "../ports/playerRosterReader";

export interface CommandExecutionResult {
  duplicate: boolean;
  events: Awaited<ReturnType<EventStore["loadStream"]>>;
  projection: LiveGameProjection;
}

export class GameCommandHandler implements CommandHandler<GameCommand, CommandExecutionResult> {
  constructor(
    private readonly eventStore: EventStore,
    private readonly projectionManager: ProjectionManager,
    private readonly eventBus: EventBus,
    private readonly clock: Clock,
    private readonly rosterReader?: PlayerRosterReader
  ) {}

  async execute(command: GameCommand): Promise<CommandExecutionResult> {
    const gameId = command.gameId;
    const history = await this.eventStore.loadStream(gameId);
    const aggregate = GameAggregate.rehydrate(gameId, history, this.clock);

    if (command.type === "RecordGoal") {
      await this.validateGoalRoster(command, aggregate);
    }
    if (command.type === "RecordPenalty") {
      await this.validatePenaltyRoster(command, aggregate);
    }

    const expectedVersion = command.expectedVersion ?? aggregate.getVersion();
    const pending = aggregate.execute(command);
    const appended = await this.eventStore.append({
      aggregateId: gameId,
      aggregateType: "game",
      expectedVersion,
      commandId: command.commandId,
      events: pending,
    });
    const completeHistory = appended.duplicate
      ? await this.eventStore.loadStream(gameId)
      : [...history, ...appended.events];
    const projection = await this.projectionManager.rebuild<LiveGameProjection>("games.live", completeHistory);
    if (!appended.duplicate) await this.eventBus.publishMany(appended.events);
    return { duplicate: appended.duplicate, events: appended.events, projection };
  }

  private async validatePenaltyRoster(
    command: Extract<GameCommand, { type: "RecordPenalty" }>,
    aggregate: GameAggregate
  ): Promise<void> {
    if (!command.playerId || !this.rosterReader) return;
    const players = await this.rosterReader.findByIds([command.playerId]);
    const player = players[0];
    if (!player) {
      throw new DomainError("The selected player was not found.", "PLAYER_NOT_FOUND", 404);
    }
    const penalizedTeamId = aggregate.getTeamId(command.side);
    if (player.teamId !== penalizedTeamId) {
      throw new DomainError(
        "The penalized player must belong to the selected team.",
        "PLAYER_NOT_ON_PENALIZED_TEAM",
        409
      );
    }
  }

  private async validateGoalRoster(
    command: Extract<GameCommand, { type: "RecordGoal" }>,
    aggregate: GameAggregate
  ): Promise<void> {
    const playerIds = [command.scorerId, ...(command.assistIds ?? [])].filter(
      (id): id is string => Boolean(id)
    );
    if (playerIds.length === 0 || !this.rosterReader) return;

    const players = await this.rosterReader.findByIds(playerIds);
    if (players.length !== new Set(playerIds).size) {
      throw new DomainError("One or more selected players were not found.", "PLAYER_NOT_FOUND", 404);
    }

    const scoringTeamId = aggregate.getTeamId(command.side);
    const wrongTeam = players.find((player) => player.teamId !== scoringTeamId);
    if (wrongTeam) {
      throw new DomainError(
        "Scorer and assists must belong to the team receiving the goal.",
        "PLAYER_NOT_ON_SCORING_TEAM",
        409
      );
    }
  }
}
