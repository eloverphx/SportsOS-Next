import type { DomainEvent } from "../../../../shared/events/domainEvent";
import type { LiveGameProjection } from "../../domain/projections/liveGameProjection";

export function projectGame(events: DomainEvent[]): LiveGameProjection | null {
  let state: LiveGameProjection | null = null;
  for (const event of events) {
    switch (event.type) {
      case "game.created": {
        const p = event.payload as any;
        state = {
          gameId: event.aggregateId,
          organizationId: p.organizationId,
          homeTeamId: p.homeTeamId,
          awayTeamId: p.awayTeamId,
          scheduledAt: p.scheduledAt,
          venue: p.venue,
          status: "scheduled",
          homeScore: 0,
          awayScore: 0,
          period: 1,
          clockMilliseconds: p.initialPeriodMilliseconds,
          clockRunning: false,
          goals: [],
          penalties: [],
          lastEventSequence: event.sequence,
          updatedAt: event.occurredAt,
        };
        break;
      }
      case "game.started": if (state) state.status = "live"; break;
      case "game.clock_started": if (state) { state.clockRunning = true; state.status = "live"; } break;
      case "game.clock_stopped": if (state) { state.clockRunning = false; state.status = "paused"; state.clockMilliseconds = (event.payload as any).remainingMilliseconds; } break;
      case "game.clock_set": if (state) state.clockMilliseconds = (event.payload as any).remainingMilliseconds; break;
      case "game.period_advanced": if (state) { state.period = (event.payload as any).period; state.clockMilliseconds = (event.payload as any).remainingMilliseconds; } break;
      case "game.goal_recorded": if (state) {
        const p = event.payload as any;
        state.goals.push({ goalId: p.goalId, side: p.side, scorerId: p.scorerId, assistIds: p.assistIds, period: p.period ?? state.period, clockMilliseconds: p.clockMilliseconds ?? state.clockMilliseconds, voided: false });
        if (p.side === "home") state.homeScore++; else state.awayScore++;
      } break;
      case "game.goal_voided": if (state) {
        const goal = state.goals.find((item) => item.goalId === (event.payload as any).goalId);
        if (goal && !goal.voided) {
          goal.voided = true;
          if (goal.side === "home") state.homeScore--; else state.awayScore--;
        }
      } break;
      case "game.penalty_recorded": if (state) {
        const p = event.payload as any;
        state.penalties.push({
          penaltyId: p.penaltyId,
          side: p.side,
          playerId: p.playerId,
          infraction: p.infraction,
          durationMilliseconds: p.durationMilliseconds,
          period: p.period ?? state.period,
          clockMilliseconds: p.clockMilliseconds ?? state.clockMilliseconds,
          voided: false,
        });
      } break;
      case "game.penalty_voided": if (state) {
        const penalty = state.penalties.find((item) => item.penaltyId === (event.payload as any).penaltyId);
        if (penalty) penalty.voided = true;
      } break;
      case "game.ended": if (state) { state.status = "final"; state.clockRunning = false; } break;
    }
    if (state) {
      state.lastEventSequence = event.sequence;
      state.updatedAt = event.occurredAt;
    }
  }
  return state;
}
