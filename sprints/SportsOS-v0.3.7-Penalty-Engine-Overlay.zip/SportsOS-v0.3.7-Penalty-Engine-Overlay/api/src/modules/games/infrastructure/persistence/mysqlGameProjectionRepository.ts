import mysql, { type Pool, type RowDataPacket } from "mysql2/promise";
import type { LiveGameProjection } from "../../domain/projections/liveGameProjection";

function pool(): Pool {
  return mysql.createPool({
    host: process.env.MYSQL_HOST ?? "mysql", port: Number(process.env.MYSQL_PORT ?? 3306),
    user: process.env.MYSQL_USER ?? "sportsos", password: process.env.MYSQL_PASSWORD ?? "sportsos123",
    database: process.env.MYSQL_DATABASE ?? "sportsos", connectionLimit: 10,
  });
}

export interface GameProjectionRepository {
  save(projection: LiveGameProjection): Promise<void>;
  findById(gameId: string): Promise<LiveGameProjection | null>;
  list(): Promise<LiveGameProjection[]>;
}

export class MysqlGameProjectionRepository implements GameProjectionRepository {
  constructor(private readonly db: Pool = pool()) {}
  async save(p: LiveGameProjection): Promise<void> {
    await this.db.execute(
      `INSERT INTO game_projections
       (game_id, organization_id, home_team_id, away_team_id, scheduled_at, venue, status,
        home_score, away_score, period_number, clock_milliseconds, clock_running, goals, penalties,
        last_event_sequence, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE status=VALUES(status), home_score=VALUES(home_score), away_score=VALUES(away_score),
       period_number=VALUES(period_number), clock_milliseconds=VALUES(clock_milliseconds),
       clock_running=VALUES(clock_running), goals=VALUES(goals), penalties=VALUES(penalties),
       last_event_sequence=VALUES(last_event_sequence), updated_at=VALUES(updated_at),
       venue=VALUES(venue), scheduled_at=VALUES(scheduled_at)`,
      [p.gameId, p.organizationId, p.homeTeamId, p.awayTeamId, mysqlDate(p.scheduledAt), p.venue, p.status,
       p.homeScore, p.awayScore, p.period, p.clockMilliseconds, p.clockRunning ? 1 : 0,
       JSON.stringify(p.goals), JSON.stringify(p.penalties), p.lastEventSequence, mysqlDate(p.updatedAt)]
    );
  }
  async findById(gameId: string): Promise<LiveGameProjection | null> {
    const [rows] = await this.db.execute<RowDataPacket[]>(`SELECT * FROM game_projections WHERE game_id = ?`, [gameId]);
    return rows[0] ? mapProjection(rows[0]) : null;
  }
  async list(): Promise<LiveGameProjection[]> {
    const [rows] = await this.db.execute<RowDataPacket[]>(`SELECT * FROM game_projections ORDER BY scheduled_at DESC`);
    return rows.map(mapProjection);
  }
}
function mysqlDate(value: string): string { return value.replace("T", " ").replace("Z", ""); }
function iso(value: unknown): string { return value instanceof Date ? value.toISOString() : new Date(String(value)).toISOString(); }
function jsonArray(value: unknown): any[] {
  if (Array.isArray(value)) return value;
  if (typeof value === "string") return JSON.parse(value) as any[];
  return [];
}
function mapProjection(row: RowDataPacket): LiveGameProjection {
  return {
    gameId: String(row.game_id), organizationId: String(row.organization_id), homeTeamId: String(row.home_team_id),
    awayTeamId: String(row.away_team_id), scheduledAt: iso(row.scheduled_at), venue: row.venue ? String(row.venue) : null,
    status: row.status, homeScore: Number(row.home_score), awayScore: Number(row.away_score), period: Number(row.period_number),
    clockMilliseconds: Number(row.clock_milliseconds), clockRunning: Boolean(row.clock_running),
    goals: jsonArray(row.goals), penalties: jsonArray(row.penalties),
    lastEventSequence: Number(row.last_event_sequence), updatedAt: iso(row.updated_at),
  };
}
