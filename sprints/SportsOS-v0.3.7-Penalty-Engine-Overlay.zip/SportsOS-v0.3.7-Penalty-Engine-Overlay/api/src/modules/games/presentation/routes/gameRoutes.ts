import { randomUUID } from "node:crypto";
import type { FastifyInstance, FastifyRequest } from "fastify";
import { ZodError } from "zod";
import { DomainError } from "../../../../shared/domain/errors";
import { requireAuthentication, requireGameControl, requireOrganizationAdmin } from "../../../../plugins/auth";
import { getAuthenticatedUser } from "../../../../utils/authUser";
import { error, ok } from "../../../../utils/reply";
import type { CommandBus } from "../../../../shared/commands/commandBus";
import type { CommandExecutionResult } from "../../application/handlers/handleGameCommand";
import type { GameProjectionRepository } from "../../infrastructure/persistence/mysqlGameProjectionRepository";
import { advancePeriodSchema, commandHeadersSchema, createGameSchema, recordGoalSchema, recordPenaltySchema, setClockSchema, stopClockSchema, voidGoalSchema, voidPenaltySchema } from "../schemas/gameSchemas";

export interface GameRouteDependencies {
  commandBus: CommandBus;
  projections: GameProjectionRepository;
}

function context(request: FastifyRequest) {
  const headers = commandHeadersSchema.parse(request.headers);
  return {
    commandId: headers["x-command-id"] ?? randomUUID(),
    correlationId: request.id,
    actorId: getAuthenticatedUser(request).id,
    expectedVersion: headers["if-match"] ? Number(headers["if-match"]) : undefined,
  };
}

export function createGameRoutes(deps: GameRouteDependencies) {
  return async function gameRoutes(fastify: FastifyInstance) {
    fastify.get("/games", { preHandler: requireAuthentication }, async (request, reply) =>
      ok(request, reply, { games: (await deps.projections.list()).map(toDto) }));

    fastify.get("/games/:id", { preHandler: requireAuthentication }, async (request, reply) => {
      const { id } = request.params as { id: string };
      const game = await deps.projections.findById(id);
      return game ? ok(request, reply, { game: toDto(game) }) : error(request, reply, 404, "Game not found.");
    });

    fastify.post("/games", { preHandler: requireOrganizationAdmin }, async (request, reply) => run(request, reply, async () => {
      const body = createGameSchema.parse(request.body);
      const result = await deps.commandBus.execute<CommandExecutionResult>({ type: "CreateGame", gameId: body.id ?? randomUUID(),
        organizationId: body.organization_id, homeTeamId: body.home_team_id, awayTeamId: body.away_team_id,
        scheduledAt: body.scheduled_at, venue: body.venue, initialPeriodMilliseconds: body.initial_period_milliseconds,
        ...context(request) });
      return ok(request, reply, { game: toDto(result.projection), duplicate: result.duplicate }, 201);
    }));

    fastify.post("/games/:id/start", { preHandler: requireGameControl }, async (request, reply) => command(request, reply, deps, "StartGame"));
    fastify.post("/games/:id/clock/start", { preHandler: requireGameControl }, async (request, reply) => command(request, reply, deps, "StartClock"));
    fastify.post("/games/:id/end", { preHandler: requireGameControl }, async (request, reply) => command(request, reply, deps, "EndGame"));

    fastify.post("/games/:id/clock/stop", { preHandler: requireGameControl }, async (request, reply) => run(request, reply, async () => {
      const body = stopClockSchema.parse(request.body); const { id } = request.params as { id: string };
      const result = await deps.commandBus.execute<CommandExecutionResult>({ type: "StopClock", gameId: id, remainingMilliseconds: body.remaining_milliseconds, ...context(request) });
      return ok(request, reply, { game: toDto(result.projection), duplicate: result.duplicate });
    }));
    fastify.post("/games/:id/clock/set", { preHandler: requireGameControl }, async (request, reply) => run(request, reply, async () => {
      const body = setClockSchema.parse(request.body); const { id } = request.params as { id: string };
      const result = await deps.commandBus.execute<CommandExecutionResult>({ type: "SetClock", gameId: id, remainingMilliseconds: body.remaining_milliseconds, ...context(request) });
      return ok(request, reply, { game: toDto(result.projection), duplicate: result.duplicate });
    }));
    fastify.post("/games/:id/period/advance", { preHandler: requireGameControl }, async (request, reply) => run(request, reply, async () => {
      const body = advancePeriodSchema.parse(request.body ?? {}); const { id } = request.params as { id: string };
      const result = await deps.commandBus.execute<CommandExecutionResult>({ type: "AdvancePeriod", gameId: id, remainingMilliseconds: body.remaining_milliseconds, ...context(request) });
      return ok(request, reply, { game: toDto(result.projection), duplicate: result.duplicate });
    }));
    fastify.post("/games/:id/goals", { preHandler: requireGameControl }, async (request, reply) => run(request, reply, async () => {
      const body = recordGoalSchema.parse(request.body); const { id } = request.params as { id: string };
      const result = await deps.commandBus.execute<CommandExecutionResult>({ type: "RecordGoal", gameId: id, goalId: body.goal_id ?? randomUUID(),
        side: body.side, scorerId: body.scorer_id, assistIds: body.assist_ids, ...context(request) });
      return ok(request, reply, { game: toDto(result.projection), duplicate: result.duplicate }, 201);
    }));
    fastify.post("/games/:id/goals/:goalId/void", { preHandler: requireGameControl }, async (request, reply) => run(request, reply, async () => {
      const body = voidGoalSchema.parse(request.body); const { id, goalId } = request.params as { id: string; goalId: string };
      const result = await deps.commandBus.execute<CommandExecutionResult>({ type: "VoidGoal", gameId: id, goalId, reason: body.reason, ...context(request) });
      return ok(request, reply, { game: toDto(result.projection), duplicate: result.duplicate });
    }));
    fastify.post("/games/:id/penalties", { preHandler: requireGameControl }, async (request, reply) => run(request, reply, async () => {
      const body = recordPenaltySchema.parse(request.body); const { id } = request.params as { id: string };
      const result = await deps.commandBus.execute<CommandExecutionResult>({ type: "RecordPenalty", gameId: id, penaltyId: body.penalty_id ?? randomUUID(),
        side: body.side, playerId: body.player_id, infraction: body.infraction, durationMilliseconds: body.duration_milliseconds, ...context(request) });
      return ok(request, reply, { game: toDto(result.projection), duplicate: result.duplicate }, 201);
    }));
    fastify.post("/games/:id/penalties/:penaltyId/void", { preHandler: requireGameControl }, async (request, reply) => run(request, reply, async () => {
      const body = voidPenaltySchema.parse(request.body); const { id, penaltyId } = request.params as { id: string; penaltyId: string };
      const result = await deps.commandBus.execute<CommandExecutionResult>({ type: "VoidPenalty", gameId: id, penaltyId, reason: body.reason, ...context(request) });
      return ok(request, reply, { game: toDto(result.projection), duplicate: result.duplicate });
    }));
  };
}

async function command(request: FastifyRequest, reply: any, deps: GameRouteDependencies, type: "StartGame" | "StartClock" | "EndGame") {
  return run(request, reply, async () => {
    const { id } = request.params as { id: string };
    const result = await deps.commandBus.execute<CommandExecutionResult>({ type, gameId: id, ...context(request) } as any);
    return ok(request, reply, { game: toDto(result.projection), duplicate: result.duplicate });
  });
}
async function run(request: FastifyRequest, reply: any, fn: () => Promise<unknown>) {
  try { return await fn(); }
  catch (err) {
    if (err instanceof ZodError) return error(request, reply, 400, "Request validation failed.", err.issues);
    if (err instanceof DomainError) return error(request, reply, err.statusCode, err.message, { code: err.code, details: err.details });
    throw err;
  }
}
function toDto(p: any) {
  return { id: p.gameId, organization_id: p.organizationId, home_team_id: p.homeTeamId, away_team_id: p.awayTeamId,
    scheduled_at: p.scheduledAt, venue: p.venue, status: p.status, home_score: p.homeScore, away_score: p.awayScore,
    period: p.period, clock_milliseconds: p.clockMilliseconds, clock_running: p.clockRunning, goals: p.goals, penalties: p.penalties,
    last_event_sequence: p.lastEventSequence, updated_at: p.updatedAt };
}
