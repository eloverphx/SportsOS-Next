import { z } from "zod";

export const commandHeadersSchema = z.object({
  "x-command-id": z.string().uuid().optional(),
  "if-match": z.string().regex(/^\d+$/).optional(),
});

export const createGameSchema = z.object({
  id: z.string().uuid().optional(),
  organization_id: z.string().uuid(),
  home_team_id: z.string().uuid(),
  away_team_id: z.string().uuid(),
  scheduled_at: z.string().datetime(),
  venue: z.string().trim().max(255).nullable().optional(),
  initial_period_milliseconds: z.number().int().positive().max(86_400_000).optional(),
});
export const stopClockSchema = z.object({ remaining_milliseconds: z.number().int().min(0).max(86_400_000) });
export const setClockSchema = stopClockSchema;
export const advancePeriodSchema = z.object({ remaining_milliseconds: z.number().int().min(0).max(86_400_000).optional() });
export const recordGoalSchema = z.object({
  goal_id: z.string().uuid().optional(),
  side: z.enum(["home", "away"]),
  scorer_id: z.string().uuid().nullable().optional(),
  assist_ids: z.array(z.string().uuid()).max(2).optional(),
});
export const voidGoalSchema = z.object({ reason: z.string().trim().min(1).max(255) });
export const recordPenaltySchema = z.object({
  penalty_id: z.string().uuid().optional(),
  side: z.enum(["home", "away"]),
  player_id: z.string().uuid().nullable().optional(),
  infraction: z.string().trim().min(1).max(100),
  duration_milliseconds: z.number().int().min(30_000).max(600_000),
});
export const voidPenaltySchema = z.object({ reason: z.string().trim().min(1).max(255) });
