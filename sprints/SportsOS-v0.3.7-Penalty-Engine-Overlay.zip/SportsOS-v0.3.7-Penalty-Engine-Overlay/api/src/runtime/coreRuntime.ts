import { InMemoryCommandBus } from "../shared/commands/commandBus";
import { InMemoryEventBus } from "../shared/events/eventBus";
import { PluginRegistry } from "../shared/plugins/pluginRegistry";
import { ProjectionManager } from "../shared/projections/projectionManager";
import { RulesEngine } from "../shared/rules/rulesEngine";
import { SystemClock } from "../shared/time/clock";
import { hockeyPlugin } from "../modules/sports/hockey/hockeyPlugin";
import { GameCommandHandler } from "../modules/games/application/handlers/handleGameCommand";
import { createLiveGameProjectionDefinition } from "../modules/games/application/services/liveGameProjectionDefinition";
import type { GameCommand } from "../modules/games/domain/commands/gameCommands";
import { MysqlEventStore } from "../modules/games/infrastructure/persistence/mysqlEventStore";
import { MysqlGameProjectionRepository } from "../modules/games/infrastructure/persistence/mysqlGameProjectionRepository";
import { registerSocketGameEventSubscriber } from "../modules/games/infrastructure/realtime/socketGameEventSubscriber";
import { MysqlPlayerRosterReader } from "../modules/games/infrastructure/rosters/mysqlPlayerRosterReader";

const GAME_COMMAND_TYPES: GameCommand["type"][] = [
  "CreateGame", "StartGame", "StartClock", "StopClock", "SetClock",
  "AdvancePeriod", "RecordGoal", "VoidGoal", "RecordPenalty", "VoidPenalty", "EndGame",
];

export function createCoreRuntime() {
  const commandBus = new InMemoryCommandBus();
  const eventBus = new InMemoryEventBus();
  const plugins = new PluginRegistry();
  const projections = new ProjectionManager();
  const rules = new RulesEngine(plugins);
  const gameProjectionRepository = new MysqlGameProjectionRepository();

  plugins.registerSport(hockeyPlugin);
  projections.register(createLiveGameProjectionDefinition(gameProjectionRepository));

  const gameCommandHandler = new GameCommandHandler(
    new MysqlEventStore(),
    projections,
    eventBus,
    new SystemClock(),
    new MysqlPlayerRosterReader()
  );
  for (const type of GAME_COMMAND_TYPES) commandBus.register(type, gameCommandHandler);
  registerSocketGameEventSubscriber(eventBus);

  return {
    commandBus,
    eventBus,
    plugins,
    projections,
    rules,
    gameProjectionRepository,
  };
}

export type CoreRuntime = ReturnType<typeof createCoreRuntime>;
