# Upgrade to SportsOS v0.3.7

1. Back up the SportsOS project and MySQL database.
2. Overlay this ZIP onto the project root.
3. Run `dashboard/docs/database/002_game_penalties.sql` against the SportsOS database once.
4. Rebuild and restart:

```bash
docker compose build --no-cache api dashboard
docker compose up -d
```

5. Open a live game's Scorekeeper Console and test home/away penalties.

## Rollback
Restore the project backup and database backup. The added `penalties` column is otherwise harmless to v0.3.6.1, but restoring the database is the cleanest rollback.
