import Fastify, { type FastifyRequest } from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import bcrypt from 'bcryptjs';
import mysql, { type Pool, type RowDataPacket } from 'mysql2/promise';
import { createClient } from 'redis';
import mqtt from 'mqtt';
import { Client as MinioClient } from 'minio';
import { Server as SocketIOServer } from 'socket.io';
import { z } from 'zod';
import { randomUUID } from 'node:crypto';

const envSchema = z.object({
  PORT: z.coerce.number().default(4001),
  HOST: z.string().default('0.0.0.0'),
  DASHBOARD_ORIGIN: z.string().default('http://localhost:4000'),
  PUBLIC_API_URL: z.string().default('http://localhost:4001'),
  MYSQL_HOST: z.string().default('mysql'),
  MYSQL_PORT: z.coerce.number().default(3306),
  MYSQL_DATABASE: z.string().default('sportsos'),
  MYSQL_USER: z.string().default('sportsos'),
  MYSQL_PASSWORD: z.string().min(1),
  JWT_SECRET: z.string().min(32),
  REDIS_URL: z.string().default('redis://redis:6379'),
  MQTT_URL: z.string().default('mqtt://mqtt:1883'),
  MINIO_ENDPOINT: z.string().default('minio'),
  MINIO_PORT: z.coerce.number().default(9000),
  MINIO_ACCESS_KEY: z.string().min(1),
  MINIO_SECRET_KEY: z.string().min(1),
  MINIO_BUCKET: z.string().default('sportsos-media')
});

const env = envSchema.parse(process.env);
const app = Fastify({ logger: true, bodyLimit: 6 * 1024 * 1024 });
await app.register(cors, { origin: env.DASHBOARD_ORIGIN, credentials: true });
await app.register(jwt, { secret: env.JWT_SECRET });

const pool: Pool = mysql.createPool({
  host: env.MYSQL_HOST,
  port: env.MYSQL_PORT,
  database: env.MYSQL_DATABASE,
  user: env.MYSQL_USER,
  password: env.MYSQL_PASSWORD,
  connectionLimit: 10
});

const minio = new MinioClient({
  endPoint: env.MINIO_ENDPOINT,
  port: env.MINIO_PORT,
  useSSL: false,
  accessKey: env.MINIO_ACCESS_KEY,
  secretKey: env.MINIO_SECRET_KEY
});

async function runMigrations(): Promise<void> {
  await pool.execute(`CREATE TABLE IF NOT EXISTS organizations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    short_name VARCHAR(50) NULL,
    default_sport VARCHAR(80) NOT NULL DEFAULT 'Hockey',
    timezone VARCHAR(100) NOT NULL DEFAULT 'America/Chicago',
    primary_color VARCHAR(7) NOT NULL DEFAULT '#ef4444',
    secondary_color VARCHAR(7) NOT NULL DEFAULT '#0f172a',
    website VARCHAR(255) NULL,
    logo_asset_id BIGINT UNSIGNED NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB`);
  await pool.execute(`CREATE TABLE IF NOT EXISTS users (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    first_name VARCHAR(80) NOT NULL,
    last_name VARCHAR(80) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(40) NOT NULL DEFAULT 'admin',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_users_org FOREIGN KEY (organization_id) REFERENCES organizations(id)
  ) ENGINE=InnoDB`);
  await pool.execute(`CREATE TABLE IF NOT EXISTS media_assets (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NULL,
    bucket VARCHAR(120) NOT NULL,
    object_key VARCHAR(500) NOT NULL UNIQUE,
    original_name VARCHAR(255) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    size_bytes BIGINT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_media_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE SET NULL
  ) ENGINE=InnoDB`);
  await pool.execute(`CREATE TABLE IF NOT EXISTS teams (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(160) NOT NULL,
    nickname VARCHAR(100) NULL,
    sport VARCHAR(80) NOT NULL DEFAULT 'Hockey',
    division VARCHAR(100) NULL,
    season VARCHAR(40) NULL,
    home_arena VARCHAR(160) NULL,
    primary_color VARCHAR(7) NOT NULL DEFAULT '#ef4444',
    secondary_color VARCHAR(7) NOT NULL DEFAULT '#0f172a',
    logo_asset_id BIGINT UNSIGNED NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_teams_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE RESTRICT,
    CONSTRAINT fk_teams_logo FOREIGN KEY (logo_asset_id) REFERENCES media_assets(id) ON DELETE SET NULL
  ) ENGINE=InnoDB`);
  await pool.execute(`CREATE TABLE IF NOT EXISTS settings (
    setting_key VARCHAR(120) NOT NULL PRIMARY KEY,
    setting_value TEXT NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB`);
  await pool.execute(`CREATE TABLE IF NOT EXISTS audit_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NULL,
    action VARCHAR(120) NOT NULL,
    details JSON NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB`);

  const columns = await pool.query<RowDataPacket[]>(`SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'organizations'`, [env.MYSQL_DATABASE]);
  const present = new Set(columns[0].map((row) => String(row.COLUMN_NAME)));
  const additions: Array<[string, string]> = [
    ['short_name', "VARCHAR(50) NULL AFTER name"],
    ['primary_color', "VARCHAR(7) NOT NULL DEFAULT '#ef4444' AFTER timezone"],
    ['secondary_color', "VARCHAR(7) NOT NULL DEFAULT '#0f172a' AFTER primary_color"],
    ['website', 'VARCHAR(255) NULL AFTER secondary_color'],
    ['logo_asset_id', 'BIGINT UNSIGNED NULL AFTER website'],
    ['active', 'BOOLEAN NOT NULL DEFAULT TRUE AFTER logo_asset_id'],
    ['updated_at', 'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at']
  ];
  for (const [name, sql] of additions) if (!present.has(name)) await pool.execute(`ALTER TABLE organizations ADD COLUMN ${name} ${sql}`);

  if (!(await minio.bucketExists(env.MINIO_BUCKET))) await minio.makeBucket(env.MINIO_BUCKET);
}
await runMigrations();

const io = new SocketIOServer(app.server, { cors: { origin: env.DASHBOARD_ORIGIN, credentials: true } });
io.on('connection', (socket) => socket.emit('system:hello', { message: 'SportsOS realtime online', timestamp: new Date().toISOString() }));

interface AuthUser { sub: string; organizationId: number; role: string }
async function requireAuth(request: FastifyRequest): Promise<void> { await request.jwtVerify(); }
function authUser(request: FastifyRequest): AuthUser { return request.user as AuthUser; }
async function audit(userId: string, action: string, details: object): Promise<void> {
  await pool.execute('INSERT INTO audit_log (user_id, action, details) VALUES (?, ?, ?)', [userId, action, JSON.stringify(details)]);
}
async function logoUrl(assetId: number | null): Promise<string | null> {
  return assetId ? `${env.PUBLIC_API_URL}/media/${assetId}` : null;
}
async function mapOrganization(row: RowDataPacket) {
  return {
    id: Number(row.id), name: row.name, shortName: row.short_name, defaultSport: row.default_sport,
    timezone: row.timezone, primaryColor: row.primary_color, secondaryColor: row.secondary_color,
    website: row.website, logoAssetId: row.logo_asset_id ? Number(row.logo_asset_id) : null,
    logoUrl: await logoUrl(row.logo_asset_id ? Number(row.logo_asset_id) : null), active: Boolean(row.active),
    teamCount: Number(row.team_count ?? 0), createdAt: row.created_at, updatedAt: row.updated_at
  };
}
async function mapTeam(row: RowDataPacket) {
  return {
    id: Number(row.id), organizationId: Number(row.organization_id), organizationName: row.organization_name,
    name: row.name, nickname: row.nickname, sport: row.sport, division: row.division, season: row.season,
    homeArena: row.home_arena, primaryColor: row.primary_color, secondaryColor: row.secondary_color,
    logoAssetId: row.logo_asset_id ? Number(row.logo_asset_id) : null,
    logoUrl: await logoUrl(row.logo_asset_id ? Number(row.logo_asset_id) : null), active: Boolean(row.active),
    createdAt: row.created_at, updatedAt: row.updated_at
  };
}

const setupSchema = z.object({
  firstName: z.string().trim().min(1).max(80), lastName: z.string().trim().min(1).max(80),
  email: z.string().trim().email().max(190), username: z.string().trim().min(3).max(80),
  password: z.string().min(10).max(128), organizationName: z.string().trim().min(2).max(160),
  defaultSport: z.string().trim().min(2).max(80).default('Hockey'), timezone: z.string().trim().min(2).max(100),
  serverName: z.string().trim().min(2).max(120)
});
app.get('/setup/status', async () => { const [rows] = await pool.query<RowDataPacket[]>('SELECT COUNT(*) AS count FROM users'); return { complete: Number(rows[0]?.count ?? 0) > 0 }; });
app.post('/setup/complete', async (request, reply) => {
  const parsed = setupSchema.safeParse(request.body); if (!parsed.success) return reply.code(400).send({ error: 'Invalid setup data', details: parsed.error.flatten() });
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [rows] = await connection.query<RowDataPacket[]>('SELECT COUNT(*) AS count FROM users FOR UPDATE');
    if (Number(rows[0]?.count ?? 0) > 0) { await connection.rollback(); return reply.code(409).send({ error: 'Setup has already been completed' }); }
    const input = parsed.data;
    const [orgResult] = await connection.execute<mysql.ResultSetHeader>('INSERT INTO organizations (name, default_sport, timezone) VALUES (?, ?, ?)', [input.organizationName, input.defaultSport, input.timezone]);
    const passwordHash = await bcrypt.hash(input.password, 12);
    const [userResult] = await connection.execute<mysql.ResultSetHeader>('INSERT INTO users (organization_id, first_name, last_name, email, username, password_hash, role) VALUES (?, ?, ?, ?, ?, ?, ?)', [orgResult.insertId, input.firstName, input.lastName, input.email.toLowerCase(), input.username, passwordHash, 'admin']);
    await connection.execute('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?), (?, ?)', ['server_name', input.serverName, 'setup_complete', 'true']);
    await connection.execute('INSERT INTO audit_log (user_id, action, details) VALUES (?, ?, ?)', [userResult.insertId, 'setup.completed', JSON.stringify({ organizationId: orgResult.insertId })]);
    await connection.commit(); return { success: true };
  } catch (error) { await connection.rollback(); request.log.error(error); return reply.code(500).send({ error: 'Setup failed' }); } finally { connection.release(); }
});

const loginSchema = z.object({ identifier: z.string().trim().min(1), password: z.string().min(1) });
app.post('/auth/login', async (request, reply) => {
  const parsed = loginSchema.safeParse(request.body); if (!parsed.success) return reply.code(400).send({ error: 'Username/email and password are required' });
  const [rows] = await pool.execute<RowDataPacket[]>(`SELECT u.id, u.organization_id, u.first_name, u.last_name, u.email, u.username, u.password_hash, u.role, o.name AS organization_name FROM users u JOIN organizations o ON o.id = u.organization_id WHERE u.username = ? OR u.email = ? LIMIT 1`, [parsed.data.identifier, parsed.data.identifier.toLowerCase()]);
  const user = rows[0]; if (!user || !(await bcrypt.compare(parsed.data.password, String(user.password_hash)))) return reply.code(401).send({ error: 'Invalid username/email or password' });
  const token = app.jwt.sign({ sub: String(user.id), organizationId: Number(user.organization_id), role: user.role }, { expiresIn: '8h' });
  await audit(String(user.id), 'auth.login', { username: user.username });
  return { token, user: { id: user.id, firstName: user.first_name, lastName: user.last_name, email: user.email, username: user.username, role: user.role, organizationName: user.organization_name } };
});
app.get('/auth/me', { preHandler: requireAuth }, async (request, reply) => {
  const [rows] = await pool.execute<RowDataPacket[]>(`SELECT u.id, u.first_name, u.last_name, u.email, u.username, u.role, o.name AS organization_name FROM users u JOIN organizations o ON o.id = u.organization_id WHERE u.id = ? LIMIT 1`, [authUser(request).sub]);
  const user = rows[0]; if (!user) return reply.code(404).send({ error: 'User not found' });
  return { user: { id: user.id, firstName: user.first_name, lastName: user.last_name, email: user.email, username: user.username, role: user.role, organizationName: user.organization_name } };
});
app.post('/auth/logout', { preHandler: requireAuth }, async () => ({ success: true }));

const color = z.string().regex(/^#[0-9a-fA-F]{6}$/);
const organizationSchema = z.object({
  name: z.string().trim().min(2).max(160), shortName: z.string().trim().max(50).nullable().optional(),
  defaultSport: z.string().trim().min(2).max(80).default('Hockey'), timezone: z.string().trim().min(2).max(100),
  primaryColor: color.default('#ef4444'), secondaryColor: color.default('#0f172a'),
  website: z.union([z.string().trim().url().max(255), z.literal(''), z.null()]).optional(),
  logoAssetId: z.number().int().positive().nullable().optional(), active: z.boolean().default(true)
});
app.get('/organizations', { preHandler: requireAuth }, async () => {
  const [rows] = await pool.query<RowDataPacket[]>(`SELECT o.*, COUNT(t.id) AS team_count FROM organizations o LEFT JOIN teams t ON t.organization_id = o.id GROUP BY o.id ORDER BY o.name`);
  return { organizations: await Promise.all(rows.map(mapOrganization)) };
});
app.get('/organizations/:id', { preHandler: requireAuth }, async (request, reply) => {
  const id = z.coerce.number().int().positive().safeParse((request.params as { id: string }).id); if (!id.success) return reply.code(400).send({ error: 'Invalid organization id' });
  const [rows] = await pool.execute<RowDataPacket[]>(`SELECT o.*, COUNT(t.id) AS team_count FROM organizations o LEFT JOIN teams t ON t.organization_id = o.id WHERE o.id = ? GROUP BY o.id`, [id.data]);
  if (!rows[0]) return reply.code(404).send({ error: 'Organization not found' }); return { organization: await mapOrganization(rows[0]) };
});
app.post('/organizations', { preHandler: requireAuth }, async (request, reply) => {
  const parsed = organizationSchema.safeParse(request.body); if (!parsed.success) return reply.code(400).send({ error: 'Invalid organization data', details: parsed.error.flatten() }); const d = parsed.data;
  const [result] = await pool.execute<mysql.ResultSetHeader>('INSERT INTO organizations (name, short_name, default_sport, timezone, primary_color, secondary_color, website, logo_asset_id, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', [d.name, d.shortName || null, d.defaultSport, d.timezone, d.primaryColor, d.secondaryColor, d.website || null, d.logoAssetId || null, d.active]);
  await audit(authUser(request).sub, 'organization.created', { organizationId: result.insertId, name: d.name }); io.emit('organization:created', { id: result.insertId }); return reply.code(201).send({ id: result.insertId });
});
app.put('/organizations/:id', { preHandler: requireAuth }, async (request, reply) => {
  const id = z.coerce.number().int().positive().safeParse((request.params as { id: string }).id); const parsed = organizationSchema.safeParse(request.body); if (!id.success || !parsed.success) return reply.code(400).send({ error: 'Invalid organization data' }); const d = parsed.data;
  const [result] = await pool.execute<mysql.ResultSetHeader>('UPDATE organizations SET name=?, short_name=?, default_sport=?, timezone=?, primary_color=?, secondary_color=?, website=?, logo_asset_id=?, active=? WHERE id=?', [d.name, d.shortName || null, d.defaultSport, d.timezone, d.primaryColor, d.secondaryColor, d.website || null, d.logoAssetId || null, d.active, id.data]);
  if (!result.affectedRows) return reply.code(404).send({ error: 'Organization not found' }); await audit(authUser(request).sub, 'organization.updated', { organizationId: id.data }); io.emit('organization:updated', { id: id.data }); return { success: true };
});
app.delete('/organizations/:id', { preHandler: requireAuth }, async (request, reply) => {
  const id = z.coerce.number().int().positive().safeParse((request.params as { id: string }).id); if (!id.success) return reply.code(400).send({ error: 'Invalid organization id' });
  const [count] = await pool.execute<RowDataPacket[]>('SELECT COUNT(*) AS count FROM teams WHERE organization_id=?', [id.data]); if (Number(count[0]?.count ?? 0) > 0) return reply.code(409).send({ error: 'Delete or move this organization’s teams first' });
  const [result] = await pool.execute<mysql.ResultSetHeader>('DELETE FROM organizations WHERE id=?', [id.data]); if (!result.affectedRows) return reply.code(404).send({ error: 'Organization not found' }); await audit(authUser(request).sub, 'organization.deleted', { organizationId: id.data }); io.emit('organization:deleted', { id: id.data }); return { success: true };
});

const teamSchema = z.object({
  organizationId: z.number().int().positive(), name: z.string().trim().min(2).max(160), nickname: z.string().trim().max(100).nullable().optional(),
  sport: z.string().trim().min(2).max(80).default('Hockey'), division: z.string().trim().max(100).nullable().optional(), season: z.string().trim().max(40).nullable().optional(),
  homeArena: z.string().trim().max(160).nullable().optional(), primaryColor: color.default('#ef4444'), secondaryColor: color.default('#0f172a'),
  logoAssetId: z.number().int().positive().nullable().optional(), active: z.boolean().default(true)
});
app.get('/teams', { preHandler: requireAuth }, async (request) => {
  const query = request.query as { organizationId?: string; search?: string }; const conditions: string[] = []; const params: Array<string | number> = [];
  if (query.organizationId) { conditions.push('t.organization_id=?'); params.push(Number(query.organizationId)); }
  if (query.search) { conditions.push('(t.name LIKE ? OR t.nickname LIKE ? OR t.division LIKE ?)'); const s = `%${query.search}%`; params.push(s, s, s); }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const [rows] = await pool.execute<RowDataPacket[]>(`SELECT t.*, o.name AS organization_name FROM teams t JOIN organizations o ON o.id=t.organization_id ${where} ORDER BY t.name`, params);
  return { teams: await Promise.all(rows.map(mapTeam)) };
});
app.get('/teams/:id', { preHandler: requireAuth }, async (request, reply) => {
  const id = z.coerce.number().int().positive().safeParse((request.params as { id: string }).id); if (!id.success) return reply.code(400).send({ error: 'Invalid team id' }); const [rows] = await pool.execute<RowDataPacket[]>('SELECT t.*, o.name AS organization_name FROM teams t JOIN organizations o ON o.id=t.organization_id WHERE t.id=?', [id.data]); if (!rows[0]) return reply.code(404).send({ error: 'Team not found' }); return { team: await mapTeam(rows[0]) };
});
app.post('/teams', { preHandler: requireAuth }, async (request, reply) => {
  const parsed = teamSchema.safeParse(request.body); if (!parsed.success) return reply.code(400).send({ error: 'Invalid team data', details: parsed.error.flatten() }); const d = parsed.data;
  const [result] = await pool.execute<mysql.ResultSetHeader>('INSERT INTO teams (organization_id, name, nickname, sport, division, season, home_arena, primary_color, secondary_color, logo_asset_id, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [d.organizationId, d.name, d.nickname || null, d.sport, d.division || null, d.season || null, d.homeArena || null, d.primaryColor, d.secondaryColor, d.logoAssetId || null, d.active]); await audit(authUser(request).sub, 'team.created', { teamId: result.insertId, name: d.name }); io.emit('team:created', { id: result.insertId }); return reply.code(201).send({ id: result.insertId });
});
app.put('/teams/:id', { preHandler: requireAuth }, async (request, reply) => {
  const id = z.coerce.number().int().positive().safeParse((request.params as { id: string }).id); const parsed = teamSchema.safeParse(request.body); if (!id.success || !parsed.success) return reply.code(400).send({ error: 'Invalid team data' }); const d = parsed.data;
  const [result] = await pool.execute<mysql.ResultSetHeader>('UPDATE teams SET organization_id=?, name=?, nickname=?, sport=?, division=?, season=?, home_arena=?, primary_color=?, secondary_color=?, logo_asset_id=?, active=? WHERE id=?', [d.organizationId, d.name, d.nickname || null, d.sport, d.division || null, d.season || null, d.homeArena || null, d.primaryColor, d.secondaryColor, d.logoAssetId || null, d.active, id.data]); if (!result.affectedRows) return reply.code(404).send({ error: 'Team not found' }); await audit(authUser(request).sub, 'team.updated', { teamId: id.data }); io.emit('team:updated', { id: id.data }); return { success: true };
});
app.delete('/teams/:id', { preHandler: requireAuth }, async (request, reply) => {
  const id = z.coerce.number().int().positive().safeParse((request.params as { id: string }).id); if (!id.success) return reply.code(400).send({ error: 'Invalid team id' }); const [result] = await pool.execute<mysql.ResultSetHeader>('DELETE FROM teams WHERE id=?', [id.data]); if (!result.affectedRows) return reply.code(404).send({ error: 'Team not found' }); await audit(authUser(request).sub, 'team.deleted', { teamId: id.data }); io.emit('team:deleted', { id: id.data }); return { success: true };
});

app.get('/media/:id', async (request, reply) => {
  const id = z.coerce.number().int().positive().safeParse((request.params as { id: string }).id);
  if (!id.success) return reply.code(400).send({ error: 'Invalid media id' });
  const [rows] = await pool.execute<RowDataPacket[]>('SELECT object_key, mime_type FROM media_assets WHERE id=? LIMIT 1', [id.data]);
  if (!rows[0]) return reply.code(404).send({ error: 'Media not found' });
  const stream = await minio.getObject(env.MINIO_BUCKET, String(rows[0].object_key));
  reply.header('Content-Type', String(rows[0].mime_type));
  reply.header('Cache-Control', 'public, max-age=3600');
  return reply.send(stream);
});

const uploadSchema = z.object({ organizationId: z.number().int().positive().nullable().optional(), fileName: z.string().trim().min(1).max(255), mimeType: z.enum(['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml']), dataBase64: z.string().min(1) });
app.post('/media/logo', { preHandler: requireAuth }, async (request, reply) => {
  const parsed = uploadSchema.safeParse(request.body); if (!parsed.success) return reply.code(400).send({ error: 'Invalid logo upload', details: parsed.error.flatten() }); const d = parsed.data;
  const buffer = Buffer.from(d.dataBase64.replace(/^data:[^;]+;base64,/, ''), 'base64'); if (!buffer.length || buffer.length > 5 * 1024 * 1024) return reply.code(413).send({ error: 'Logo must be between 1 byte and 5 MB' });
  const ext = d.mimeType === 'image/png' ? 'png' : d.mimeType === 'image/jpeg' ? 'jpg' : d.mimeType === 'image/webp' ? 'webp' : 'svg'; const key = `logos/${new Date().getUTCFullYear()}/${randomUUID()}.${ext}`;
  await minio.putObject(env.MINIO_BUCKET, key, buffer, buffer.length, { 'Content-Type': d.mimeType });
  const [result] = await pool.execute<mysql.ResultSetHeader>('INSERT INTO media_assets (organization_id, bucket, object_key, original_name, mime_type, size_bytes) VALUES (?, ?, ?, ?, ?, ?)', [d.organizationId || null, env.MINIO_BUCKET, key, d.fileName, d.mimeType, buffer.length]);
  await audit(authUser(request).sub, 'logo.uploaded', { assetId: result.insertId, objectKey: key }); io.emit('logo:uploaded', { id: result.insertId }); return reply.code(201).send({ id: result.insertId, url: await logoUrl(result.insertId) });
});

app.get('/dashboard/stats', { preHandler: requireAuth }, async () => {
  const [orgRows] = await pool.query<RowDataPacket[]>('SELECT COUNT(*) AS count FROM organizations WHERE active=TRUE'); const [teamRows] = await pool.query<RowDataPacket[]>('SELECT COUNT(*) AS count FROM teams WHERE active=TRUE');
  return { organizations: Number(orgRows[0]?.count ?? 0), teams: Number(teamRows[0]?.count ?? 0), activeGames: 0, liveStreams: 0 };
});
app.get('/audit/recent', { preHandler: requireAuth }, async () => { const [rows] = await pool.query<RowDataPacket[]>('SELECT id, action, details, created_at FROM audit_log ORDER BY id DESC LIMIT 20'); return { events: rows }; });

async function checkMysql(): Promise<'online' | 'offline'> { try { await pool.query('SELECT 1'); return 'online'; } catch { return 'offline'; } }
async function checkRedis(): Promise<'online' | 'offline'> { const client = createClient({ url: env.REDIS_URL, socket: { connectTimeout: 3000 } }); try { await client.connect(); await client.ping(); await client.quit(); return 'online'; } catch { if (client.isOpen) await client.disconnect(); return 'offline'; } }
async function checkMqtt(): Promise<'online' | 'offline'> { return new Promise((resolve) => { const client = mqtt.connect(env.MQTT_URL, { connectTimeout: 3000, reconnectPeriod: 0 }); const timer = setTimeout(() => { client.end(true); resolve('offline'); }, 3500); client.once('connect', () => { clearTimeout(timer); client.end(true); resolve('online'); }); client.once('error', () => { clearTimeout(timer); client.end(true); resolve('offline'); }); }); }
async function checkMinio(): Promise<'online' | 'offline'> { try { await minio.listBuckets(); return 'online'; } catch { return 'offline'; } }

app.get('/', async () => ({ name: 'SportsOS API', version: '0.3.1-sprint1.2', endpoints: ['/', '/health', '/version', '/organizations', '/teams', '/media/logo', '/dashboard/stats'] }));
app.get('/version', async () => ({ name: 'SportsOS API', version: '0.3.1-sprint1.2', node: process.version }));
app.get('/health', async () => { const [mysqlStatus, redisStatus, mqttStatus, minioStatus] = await Promise.all([checkMysql(), checkRedis(), checkMqtt(), checkMinio()]); const services = { mysql: mysqlStatus, redis: redisStatus, mqtt: mqttStatus, minio: minioStatus }; const healthy = Object.values(services).every((status) => status === 'online'); return { success: healthy, status: healthy ? 'healthy' : 'degraded', services, uptime: Math.round(process.uptime()) }; });

await app.listen({ host: env.HOST, port: env.PORT });
